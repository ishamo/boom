#ifndef	__MP3DECODE_H__
#define	__MP3DECODE_H__

int pcm2mp3() ;

#endif  
